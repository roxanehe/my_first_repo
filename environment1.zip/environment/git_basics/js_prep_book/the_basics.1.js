console.log('ruoxin ' + 'he') // 1
let number = 4936
let ones = number % 10
number = (number - ones) / 10
let tens = number % 10
number = (number - tens) / 10
let hundreds = number % 10
let thousands = (number - hundreds) / 10 //2
console.log(Number('5') + 10); //5
console.log(`the value of 5 + 10 is ${Number('5') + 10}.`); //6
let names = [ 'asta', 'butterscotch', 'pudding', 'neptune', 'darwin' ]; //8
let pets = { asta: 'dog', butterscotch: 'cat', pudding: 'cat', neptune: 'fish', darwin: 'lizard' }; //9
false // 10
3 //11
true // 12
